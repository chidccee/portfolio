import csv
import pandas as pd
from pathlib import Path
from mutators import MUTATORS


REAL_DATASET_PATH = Path("datasets/neuralchemy_dataset.csv")


def detect_columns(df):
    print("Dataset columns:", list(df.columns))

    prompt_col = None
    label_col = None

    for col in df.columns:
        lower = col.lower()
        if lower in ["prompt", "text", "input", "user_input", "content"]:
            prompt_col = col
        if lower in ["label", "class", "target", "is_malicious"]:
            label_col = col

    if prompt_col is None:
        prompt_col = df.columns[0]

    if label_col is None:
        label_col = df.columns[-1]

    print("Using prompt column:", prompt_col)
    print("Using label column:", label_col)

    return prompt_col, label_col


def is_malicious_label(value):
    value = str(value).lower()

    return (
        "malicious" in value
        or "attack" in value
        or "injection" in value
        or "jailbreak" in value
        or value in ["1", "true", "unsafe"]
    )


def generate_dataset(output_path: str = "generated_prompts.csv") -> None:
    if not REAL_DATASET_PATH.exists():
        raise FileNotFoundError(
            "Не найден datasets/neuralchemy_dataset.csv. "
            "Сначала запусти python download_datasets.py"
        )

    df = pd.read_csv(REAL_DATASET_PATH)
    prompt_col, label_col = detect_columns(df)

    df = df.dropna(subset=[prompt_col, label_col])

    malicious_df = df[df[label_col].apply(is_malicious_label)]
    safe_df = df[~df[label_col].apply(is_malicious_label)]

    if len(malicious_df) == 0:
        raise ValueError("Не удалось найти malicious-примеры в датасете.")

    if len(safe_df) == 0:
        raise ValueError("Не удалось найти safe-примеры в датасете.")

    malicious_sample = malicious_df.sample(
        n=min(20, len(malicious_df)),
        random_state=42
    )

    safe_sample = safe_df.sample(
        n=min(20, len(safe_df)),
        random_state=42
    )

    rows = []
    idx = 1

    for _, row in safe_sample.iterrows():
        rows.append({
            "id": idx,
            "label": "safe",
            "category": "real_benign",
            "mutation": "none",
            "prompt": str(row[prompt_col]),
            "expected": "allow",
            "source": "neuralchemy/Prompt-injection-dataset"
        })
        idx += 1

    for _, row in malicious_sample.iterrows():
        seed_prompt = str(row[prompt_col])

        rows.append({
            "id": idx,
            "label": "malicious",
            "category": "real_prompt_injection",
            "mutation": "real_seed",
            "prompt": seed_prompt,
            "expected": "block",
            "source": "neuralchemy/Prompt-injection-dataset"
        })
        idx += 1

        for mutation_name, mutator in MUTATORS.items():
            if mutation_name == "raw":
                continue

            rows.append({
                "id": idx,
                "label": "malicious",
                "category": "mutated_prompt_injection",
                "mutation": mutation_name,
                "prompt": mutator(seed_prompt),
                "expected": "block",
                "source": "neuralchemy/Prompt-injection-dataset + local mutation engine"
            })
            idx += 1

    with open(output_path, "w", encoding="utf-8", newline="") as file:
        fieldnames = [
            "id",
            "label",
            "category",
            "mutation",
            "prompt",
            "expected",
            "source"
        ]
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print("Generated dataset saved to:", output_path)
    print("Safe examples:", len(safe_sample))
    print("Real malicious seeds:", len(malicious_sample))
    print("Total generated prompts:", len(rows))