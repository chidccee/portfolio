import argparse
import csv
import json
import logging
from pathlib import Path

from config import DEFAULT_MODELS, RISK_THRESHOLD
from dataset_generator import generate_dataset
from evaluator import attack_succeeded
from guard import analyze_prompt
from llm_client import ask_ollama
from metrics import (
    calculate_global_metrics,
    save_group_metrics,
    get_top_bypassed_categories,
    save_top_bypassed_categories
)
from structured_escaping import escape_structured_sequences


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)


def load_prompts(path: str) -> list:
    with open(path, "r", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def parse_models(models_arg: str) -> list:
    if not models_arg:
        return DEFAULT_MODELS

    return [
        model.strip()
        for model in models_arg.split(",")
        if model.strip()
    ]


def save_sanitization_examples(prompts: list) -> None:
    rows = []

    for item in prompts[:30]:
        original = item["prompt"]
        escaped = escape_structured_sequences(original)

        rows.append({
            "id": item["id"],
            "category": item["category"],
            "mutation": item["mutation"],
            "original": original,
            "escaped": escaped,
        })

    with open("sanitization_examples.csv", "w", encoding="utf-8", newline="") as file:
        fieldnames = [
            "id",
            "category",
            "mutation",
            "original",
            "escaped",
        ]

        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--models",
        default=",".join(DEFAULT_MODELS)
    )

    parser.add_argument(
        "--dataset",
        default="generated_prompts.csv"
    )

    parser.add_argument(
        "--regenerate",
        action="store_true"
    )

    parser.add_argument(
        "--skip-llm",
        action="store_true"
    )

    parser.add_argument(
        "--threshold",
        type=int,
        default=RISK_THRESHOLD
    )

    args = parser.parse_args()
    models = parse_models(args.models)

    dataset_path = Path(args.dataset)

    if args.regenerate or not dataset_path.exists():
        logging.info("Generating dataset...")
        generate_dataset(str(dataset_path))

    prompts = load_prompts(str(dataset_path))
    save_sanitization_examples(prompts)

    logging.info("Loaded %d prompts", len(prompts))
    logging.info("Models: %s", ", ".join(models))

    results = []

    for model in models:
        logging.info("Starting tests for model: %s", model)

        for item in prompts:
            prompt_id = item["id"]
            label = item["label"]
            category = item["category"]
            mutation = item["mutation"]
            prompt = item["prompt"]

            logging.info(
                "Model=%s | prompt=%s | label=%s | category=%s | mutation=%s",
                model,
                prompt_id,
                label,
                category,
                mutation
            )

            guard_result = analyze_prompt(
                prompt,
                threshold=args.threshold
            )

            baseline_response = "[SKIPPED]"
            protected_response = "[SKIPPED]"
            baseline_attack_result = "not_checked"
            protected_attack_result = "not_checked"

            if not args.skip_llm and label == "malicious":
                try:
                    baseline_response = ask_ollama(
                        model,
                        prompt,
                        secure_mode=False
                    )

                    baseline_attack_result = (
                        "yes"
                        if attack_succeeded(baseline_response)
                        else "no"
                    )

                except Exception as error:
                    baseline_response = f"[BASELINE OLLAMA ERROR: {error}]"
                    baseline_attack_result = "error"

            if guard_result.decision == "blocked":
                protected_response = "[BLOCKED BY GUARD]"
                protected_attack_result = "not_sent_to_llm"

            else:
                if not args.skip_llm:
                    try:
                        protected_response = ask_ollama(
                            model,
                            prompt,
                            secure_mode=True
                        )

                        protected_attack_result = (
                            "yes"
                            if attack_succeeded(protected_response)
                            else "no"
                        )

                    except Exception as error:
                        protected_response = f"[PROTECTED OLLAMA ERROR: {error}]"
                        protected_attack_result = "error"

            results.append({
                "model": model,
                "id": prompt_id,
                "label": label,
                "category": category,
                "mutation": mutation,
                "prompt": prompt,
                "expected": item["expected"],
                "guard_decision": guard_result.decision,
                "risk_score": guard_result.risk_score,
                "severity": guard_result.severity,
                "detected_categories": ", ".join(
                    guard_result.detected_categories
                ),
                "guard_reasons": " | ".join(
                    guard_result.reasons
                ),
                "sanitized_prompt": guard_result.sanitized_prompt,
                "baseline_attack_succeeded": baseline_attack_result,
                "protected_attack_succeeded": protected_attack_result,
                "baseline_response": baseline_response.replace("\n", " "),
                "protected_response": protected_response.replace("\n", " "),
            })

    with open("results.csv", "w", encoding="utf-8", newline="") as file:
        fieldnames = [
            "model",
            "id",
            "label",
            "category",
            "mutation",
            "prompt",
            "expected",
            "guard_decision",
            "risk_score",
            "severity",
            "detected_categories",
            "guard_reasons",
            "sanitized_prompt",
            "baseline_attack_succeeded",
            "protected_attack_succeeded",
            "baseline_response",
            "protected_response",
        ]

        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

    metrics = calculate_global_metrics(results)

    with open("metrics.json", "w", encoding="utf-8") as file:
        json.dump(
            metrics,
            file,
            ensure_ascii=False,
            indent=2
        )

    save_group_metrics(
        results,
        "model",
        "model_metrics.csv"
    )

    save_group_metrics(
        results,
        "category",
        "category_metrics.csv"
    )

    save_group_metrics(
        results,
        "mutation",
        "mutation_metrics.csv"
    )

    save_top_bypassed_categories(
        results,
        "top_bypassed_categories.csv"
    )

    top_bypassed = get_top_bypassed_categories(results)

    print("\n=== GLOBAL METRICS ===")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))

    print("\n=== TOP BYPASSED ATTACK TYPES ===")

    if not top_bypassed:
        print("No bypassed malicious prompts detected.")
    else:
        for mutation, count in top_bypassed:
            print(f"{mutation}: {count}")

    print(
        "\nSaved: results.csv, metrics.json, model_metrics.csv, "
        "category_metrics.csv, mutation_metrics.csv, "
        "top_bypassed_categories.csv"
    )


if __name__ == "__main__":
    main()