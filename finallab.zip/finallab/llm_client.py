import requests

from config import OLLAMA_URL, MAX_RESPONSE_TOKENS, REQUEST_TIMEOUT_SECONDS
from prompt_hardening import SECURE_SYSTEM_PROMPT
from structured_escaping import serialize_as_untrusted_user_data


def ask_ollama(model: str, prompt: str, secure_mode: bool = True) -> str:
    if secure_mode:
        user_data = serialize_as_untrusted_user_data(prompt)
        final_prompt = SECURE_SYSTEM_PROMPT + "\n\nUntrusted user input:\n" + user_data
    else:
        final_prompt = prompt

    payload = {
        "model": model,
        "prompt": final_prompt,
        "stream": False,
        "options": {
            "temperature": 0.2,
            "num_predict": MAX_RESPONSE_TOKENS
        }
    }

    response = requests.post(
        OLLAMA_URL,
        json=payload,
        timeout=REQUEST_TIMEOUT_SECONDS
    )
    response.raise_for_status()

    return response.json().get("response", "")
