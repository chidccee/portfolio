import json
import re
from dataclasses import dataclass, field
from typing import Dict, List

from sanitizer import normalize_for_analysis, remove_invisible_unicode


@dataclass
class GuardResult:
    decision: str
    risk_score: int
    severity: str
    detected_categories: List[str] = field(default_factory=list)
    reasons: List[str] = field(default_factory=list)
    sanitized_prompt: str = ""
    features: Dict[str, int] = field(default_factory=dict)


PATTERN_GROUPS = {
    "instruction_override": [
        r"ignore\s+(all\s+)?previous\s+instructions",
        r"disregard\s+(all\s+)?previous\s+instructions",
        r"forget\s+previous\s+instructions",
        r"ignore\s+the\s+above",
        r"ignore\s+the\s+rules",
        r"override\s+instructions",
        r"не\s+обращай\s+внимания\s+на\s+правила",
        r"игнорируй.*инструкц",
        r"игнорируй.*правил",
        r"забудь.*инструкц",
        r"забудь.*правил",
    ],

    "system_prompt_extraction": [
        r"system\s+prompt",
        r"hidden\s+instructions",
        r"developer\s+instructions",
        r"developer\s+message",
        r"private\s+rules",
        r"internal\s+policy",
        r"confidential\s+instructions",
        r"reveal\s+.*prompt",
        r"show\s+.*prompt",
        r"print\s+.*prompt",
        r"раскр(ой|ыть).*системн",
        r"покажи.*системн",
        r"выведи.*системн",
        r"скрыт.*инструкц",
        r"какие\s+инструкции\s+ты\s+скрываешь",
        r"format\s+your\s+instructions",
        r"reveal\s+.*all\s+.*instructions",
        r"inner\s+monologue\s+reveals\s+all\s+.*instructions",
        r"all\s+their\s+instructions",
    ],

    "data_exfiltration": [
        r"recite\s+.*(email|phone|address|password|secret|token|api\s+key)",
        r"reveal\s+.*(email|phone|address|password|secret|token|api\s+key)",
        r"show\s+.*(email|phone|address|password|secret|token|api\s+key)",
        r"print\s+.*(email|phone|address|password|secret|token|api\s+key)",
        r"list\s+.*(email|phone|address|password|secret|token|api\s+key)",
        r"dump\s+.*(email|phone|address|password|secret|token|api\s+key)",
        r"extract\s+.*(email|phone|address|password|secret|token|api\s+key)",
        r"выведи\s+.*(email|почт|телефон|адрес|парол|секрет|токен|ключ)",
        r"покажи\s+.*(email|почт|телефон|адрес|парол|секрет|токен|ключ)",
        r"раскр(ой|ыть)\s+.*(email|почт|телефон|адрес|парол|секрет|токен|ключ)",
    ],

    "command_execution": [
        r"\brun\s*:\s*`",
        r"\bexecute\s*:\s*`",
        r"\bexec\s+whoami\b",
        r"\bwhoami\b",
        r"child_process",
        r"\bos\.system\b",
        r"process\.runsync",
    ],

    "evaluation_trigger": [
        r"\bpwned\b",
        r"i\s+have\s+been\s+pwned",
        r"i'?ve\s+been\s+pwned",
        r"respond\s+with\s+['\"]?i\s+have\s+been\s+pwned",
        r"answer\s+with\s+the\s+special\s+token",
    ],

    "harmful_request": [
        r"unauthorized\s+inf",
        r"force\s+.*model\s+to\s+give\s+me\s+unauthorized",
        r"force\s+.*to\s+give\s+me\s+unauthorized",
        r"identity\s+theft",
        r"commit\s+identity\s+theft",
    ],

    "role_override": [
        r"forget\s+(that\s+)?you\s+are",
        r"from\s+now\s+on\s+you\s+are",
        r"you\s+are\s+not\s+an\s+assistant",
        r"act\s+as",
        r"pretend\s+you\s+are",
        r"simulate\s+being",
        r"debug\s+console",
        r"developer\s+mode",
        r"admin\s+mode",
        r"root\s+mode",
        r"забудь.*ассистент",
        r"теперь\s+ты\s+администратор",
        r"теперь\s+ты",
        r"представь\s+что\s+ты",
        r"режим(е)?\s+разработчика",
    ],

    "jailbreak": [
        r"\bDAN\b",
        r"unrestricted\s+AI",
        r"no\s+safety\s+policy",
        r"safety\s+disabled",
        r"without\s+restrictions",
        r"no\s+restrictions",
        r"restrictions\s*=\s*none",
        r"bypass\s+restrictions",
        r"jailbreak",
        r"у\s+тебя\s+нет\s+правил",
        r"без\s+ограничений",
        r"без\s+правил",
        r"без\s+цензуры",
    ],

    "policy_disable": [
        r"safety\s*:\s*off",
        r"safety\s*=\s*off",
        r"policy\s*:\s*disabled",
        r"policy\s*=\s*disabled",
        r"ignore_safety",
        r"disable\s+safety",
        r"bypass\s+safety",
        r"turn\s+off\s+safety",
        r"reveal_hidden_prompt\s*=\s*true",
        r"reveal_system_prompt\s*:\s*true",
        r"security\s*:\s*off",
    ],

    "delimiter_attack": [
        r"system\s+override",
        r"begin\s+system\s+mode",
        r"end\s+user\s+mode",
        r"###\s*system",
        r"###\s*begin",
        r"###\s*end",
        r"\[system\]",
        r"\[developer\]",
        r"<system>",
        r"</system>",
    ],

    "indirect_injection": [
        r"this\s+is\s+only\s+a\s+quote",
        r"just\s+a\s+quote",
        r"quoted\s+text",
        r"the\s+following\s+is\s+a\s+quote",
        r"the\s+following\s+text\s+is\s+not\s+an\s+instruction",
        r"but\s+execute\s+it\s+anyway",
        r"выполни\s+е[ёе]\s+буквально",
        r"это\s+только\s+цитата",
        r"просто\s+цитата",
        r"следующий\s+текст\s+это\s+цитата",
    ],

    "social_engineering": [
        r"for\s+educational\s+purposes",
        r"for\s+research\s+purposes",
        r"for\s+testing\s+purposes",
        r"security\s+research",
        r"authorized\s+test",
        r"please\s+just",
        r"kindly",
        r"для\s+учебн",
        r"для\s+тестирован",
        r"для\s+исследован",
        r"пожалуйста\s+просто",
    ],
}


def contains_invisible_unicode(original: str, sanitized: str) -> bool:
    return original != remove_invisible_unicode(original)


def looks_like_structured_injection(text: str) -> bool:
    lowered = text.lower().strip()

    markers = [
        "<instruction>",
        "</instruction>",
        "<policy>",
        "</policy>",
        "<system>",
        "</system>",
        "```yaml",
        "```json",
        "```xml",
        "```",
        "{",
        "}",
    ]

    if any(marker in lowered for marker in markers):
        return True

    if re.search(
        r"\b(policy|safety|instruction|system|developer|role|mode|rules)\s*[:=]",
        lowered
    ):
        return True

    if lowered.startswith("{") and lowered.endswith("}"):
        try:
            obj = json.loads(text)

            suspicious_keys = {
                "instruction",
                "task",
                "policy",
                "system",
                "developer",
                "safety",
                "role",
                "mode",
                "rules",
            }

            return any(
                str(k).lower() in suspicious_keys
                for k in obj.keys()
            )

        except Exception:
            return True

    return False


def calculate_severity(score: int) -> str:
    if score >= 10:
        return "CRITICAL"

    if score >= 6:
        return "HIGH"

    if score >= 3:
        return "MEDIUM"

    return "LOW"


def add_pattern_hits(
    normalized_texts: list,
    risk_score: int,
    reasons: list,
    categories: list,
    features: dict
) -> int:
    for category, patterns in PATTERN_GROUPS.items():
        hits = 0

        for pattern in patterns:
            if any(
                re.search(
                    pattern,
                    normalized,
                    flags=re.IGNORECASE | re.DOTALL
                )
                for normalized in normalized_texts
            ):
                hits += 1
                reasons.append(f"{category}: {pattern}")

        if hits:
            categories.append(category)
            features[category] = hits

            if category in {
                "instruction_override",
                "system_prompt_extraction",
                "data_exfiltration",
                "command_execution",
                "evaluation_trigger",
                "harmful_request",
                "jailbreak",
                "policy_disable",
            }:
                risk_score += hits * 3

            elif category in {
                "role_override",
                "delimiter_attack",
                "structured_injection",
            }:
                risk_score += hits * 2

            else:
                risk_score += hits

    return risk_score


def add_combination_risks(
    normalized: str,
    risk_score: int,
    reasons: list,
    features: dict
) -> int:
    if "role_override" in features and "system_prompt_extraction" in features:
        risk_score += 4
        reasons.append(
            "combined_risk: role override + hidden instruction extraction"
        )

    if "instruction_override" in features and "policy_disable" in features:
        risk_score += 4
        reasons.append(
            "combined_risk: instruction override + policy disabling"
        )

    if "structured_injection" in features and "policy_disable" in features:
        risk_score += 4
        reasons.append(
            "combined_risk: structured policy + policy disabling"
        )

    if "indirect_injection" in features and (
        "instruction_override" in features
        or "system_prompt_extraction" in features
        or "data_exfiltration" in features
        or "role_override" in features
    ):
        risk_score += 4
        reasons.append(
            "combined_risk: indirect wrapper + malicious instruction"
        )

    if "social_engineering" in features and (
        "instruction_override" in features
        or "system_prompt_extraction" in features
        or "data_exfiltration" in features
        or "jailbreak" in features
        or "policy_disable" in features
    ):
        risk_score += 3
        reasons.append(
            "combined_risk: social engineering + malicious instruction"
        )

    # Общий weak-signal detection:
    # если в промпте много слабых признаков, он всё равно считается рискованным.
    weak_signals = [
        "indirect_injection",
        "social_engineering",
        "delimiter_attack",
        "role_override",
    ]

    weak_count = sum(
        1 for signal in weak_signals
        if signal in features
    )

    if weak_count >= 2:
        risk_score += 2
        reasons.append(
            "combined_risk: multiple weak prompt-injection indicators"
        )

    return risk_score


def analyze_prompt(prompt: str, threshold: int = 3) -> GuardResult:
    sanitized_prompt = remove_invisible_unicode(prompt)
    basic_normalized = remove_invisible_unicode(prompt).lower()
    normalized = normalize_for_analysis(prompt)
    normalized_texts = [
        basic_normalized,
        normalized,
    ]

    risk_score = 0
    reasons = []
    categories = []
    features = {}

    risk_score = add_pattern_hits(
        normalized_texts=normalized_texts,
        risk_score=risk_score,
        reasons=reasons,
        categories=categories,
        features=features
    )

    if contains_invisible_unicode(prompt, sanitized_prompt):
        categories.append("unicode_obfuscation")
        features["unicode_obfuscation"] = 1
        reasons.append(
            "unicode_obfuscation: invisible Unicode characters detected and removed"
        )
        risk_score += 4

    if looks_like_structured_injection(normalized):
        categories.append("structured_injection")
        features["structured_injection"] = 1
        reasons.append(
            "structured_injection: suspicious JSON/XML/YAML/Markdown structure detected"
        )
        risk_score += 3

    risk_score = add_combination_risks(
        normalized=normalized,
        risk_score=risk_score,
        reasons=reasons,
        features=features
    )

    decision = "blocked" if risk_score >= threshold else "allowed"

    return GuardResult(
        decision=decision,
        risk_score=risk_score,
        severity=calculate_severity(risk_score),
        detected_categories=sorted(set(categories)),
        reasons=reasons,
        sanitized_prompt=sanitized_prompt,
        features=features
    )
