from datasets import load_dataset
import pandas as pd
from pathlib import Path

Path("datasets").mkdir(exist_ok=True)

print("Downloading Neuralchemy dataset...")

dataset = load_dataset(
    "neuralchemy/Prompt-injection-dataset",
    split="train"
)

print("Converting to DataFrame...")

df = pd.DataFrame(dataset)

print("Saving CSV...")

df.to_csv(
    "datasets/neuralchemy_dataset.csv",
    index=False,
    encoding="utf-8"
)

print("Done.")
print("Rows:", len(df))