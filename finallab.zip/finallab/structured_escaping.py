import html
import json
import re


def escape_structured_sequences(text: str) -> str:
    """
    Экранирует специальные последовательности в structured input,
    чтобы JSON/XML/YAML/Markdown не воспринимались как управляющие инструкции.
    """
    escaped = text

    # XML/HTML escaping
    escaped = html.escape(escaped)

    # Markdown/code fence escaping
    escaped = escaped.replace("```", "`\\`\\`")

    # System-like delimiters
    escaped = re.sub(r"(?i)###\s*system", "### [escaped-system-marker]", escaped)
    escaped = re.sub(r"(?i)system\s+override", "[escaped-system-override]", escaped)

    # YAML-like dangerous keys
    escaped = re.sub(r"(?i)\bpolicy\s*:", "policy_escaped:", escaped)
    escaped = re.sub(r"(?i)\bsafety\s*:", "safety_escaped:", escaped)
    escaped = re.sub(r"(?i)\binstruction\s*:", "instruction_escaped:", escaped)

    return escaped


def serialize_as_untrusted_user_data(text: str) -> str:
    """
    Оборачивает пользовательский ввод как данные, а не как инструкцию.
    """
    return json.dumps({
        "type": "untrusted_user_input",
        "content": escape_structured_sequences(text)
    }, ensure_ascii=False)
