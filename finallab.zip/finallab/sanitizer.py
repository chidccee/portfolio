import unicodedata


LEETSPEAK_MAP = str.maketrans({
    "0": "o",
    "1": "i",
    "3": "e",
    "4": "a",
    "5": "s",
    "7": "t",
    "@": "a",
    "$": "s",
    "!": "i",
})


CYRILLIC_LATIN_MAP = str.maketrans({
    "а": "a",
    "е": "e",
    "о": "o",
    "р": "p",
    "с": "c",
    "х": "x",
    "у": "y",
    "А": "A",
    "Е": "E",
    "О": "O",
    "Р": "P",
    "С": "C",
    "Х": "X",
    "У": "Y",
})


def remove_invisible_unicode(text: str) -> str:
    """
    Удаляет невидимые Unicode-символы:
    zero-width space, zero-width joiner, BOM, управляющие символы.
    """
    allowed_controls = {"\n", "\t", "\r"}
    result = []

    for ch in text:
        if ch in allowed_controls:
            result.append(ch)
            continue

        category = unicodedata.category(ch)

        if category in {"Cf", "Cc"}:
            continue

        result.append(ch)

    return "".join(result)


def normalize_leetspeak(text: str) -> str:
    """
    Преобразует простую leetspeak-обфускацию:
    1gn0r3 -> ignore
    s4f3ty -> safety
    """
    return text.translate(LEETSPEAK_MAP)


def normalize_cyrillic_latin_homoglyphs(text: str) -> str:
    """
    Заменяет похожие кириллические символы на латинские,
    чтобы ловить homoglyph-obfuscation.
    """
    return text.translate(CYRILLIC_LATIN_MAP)


def normalize_for_analysis(text: str) -> str:
    """
    Нормализация для анализа:
    - Unicode NFKC;
    - удаление invisible Unicode;
    - замена homoglyph символов;
    - deobfuscation leetspeak;
    - lower-case.
    """
    text = unicodedata.normalize("NFKC", text)
    text = remove_invisible_unicode(text)
    text = normalize_cyrillic_latin_homoglyphs(text)
    text = normalize_leetspeak(text)
    return text.lower()